const Verification = require('../models/verificationModel');

// Verify Access
const verifyAccess = async (req, res, next) => {
    try {
        const verification = await Verification.findOne({ isActive: true });
        
        if (!verification) {
            return res.json({
                data: {
                    success: 2,
                    message: "Access denied. Verification required.",
                    error: 1
                }
            });
        }

        next();
    } catch (error) {
        return res.json({
            data: {
                success: 0,
                message: "Verification check failed",
                error: error.message
            }
        });
    }
};


const verifyAdminAccess = async (req, res, next) => {
    next();
};

module.exports = {
    verifyAccess,
    verifyAdminAccess
};